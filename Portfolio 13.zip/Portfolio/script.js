// Mobile Navigation Toggle
const menuIcon = document.querySelector("#menu-icon")
const navbar = document.querySelector("nav")

menuIcon.addEventListener("click", () => {
  navbar.classList.toggle("active")

  // Change menu icon
  if (navbar.classList.contains("active")) {
    menuIcon.classList.replace("bx-menu", "bx-x")
  } else {
    menuIcon.classList.replace("bx-x", "bx-menu")
  }
})

// Close mobile menu when clicking on a link
const navLinks = document.querySelectorAll("header nav a")
navLinks.forEach((link) => {
  link.addEventListener("click", () => {
    navbar.classList.remove("active")
    menuIcon.classList.replace("bx-x", "bx-menu")
  })
})

// Close mobile menu when clicking outside
document.addEventListener("click", (e) => {
  if (!navbar.contains(e.target) && !menuIcon.contains(e.target)) {
    navbar.classList.remove("active")
    menuIcon.classList.replace("bx-x", "bx-menu")
  }
})

// Handle window resize
window.addEventListener("resize", () => {
  if (window.innerWidth > 768) {
    navbar.classList.remove("active")
    menuIcon.classList.replace("bx-x", "bx-menu")
  }
})

// Smooth scrolling navigation
const sections = document.querySelectorAll("section")

// Handle navigation clicks
navLinks.forEach((link) => {
  link.addEventListener("click", (e) => {
    e.preventDefault()
    const targetId = link.getAttribute("href")
    const targetSection = document.querySelector(targetId)

    if (targetSection) {
      targetSection.scrollIntoView({
        behavior: "smooth",
        block: "start",
      })
    }
  })
})

// Update active navigation link based on scroll position
function updateActiveNavLink() {
  let current = ""
  const scrollPosition = window.scrollY + 200 // Offset for header height

  sections.forEach((section) => {
    const sectionTop = section.offsetTop
    const sectionHeight = section.offsetHeight

    if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
      current = section.getAttribute("id")
    }
  })

  navLinks.forEach((link) => {
    link.classList.remove("active")
    if (link.getAttribute("href") === `#${current}`) {
      link.classList.add("active")
    }
  })
}

// Listen for scroll events
window.addEventListener("scroll", updateActiveNavLink)

// Set initial active link
document.addEventListener("DOMContentLoaded", () => {
  updateActiveNavLink()
})

document.addEventListener("DOMContentLoaded", () => {
  const words = ["Student", "Coder", "Gamer", "Techie"]
  let i = 0
  let j = 0
  let isDeleting = false
  const typedText = document.getElementById("typed-text")

  function type() {
    const currentWord = words[i]

    if (isDeleting) {
      typedText.textContent = currentWord.substring(0, j--)
    } else {
      typedText.textContent = currentWord.substring(0, j++)
    }

    if (!isDeleting && j === currentWord.length + 1) {
      isDeleting = true
      setTimeout(type, 1000)
      return
    }

    if (isDeleting && j === 0) {
      isDeleting = false
      i = (i + 1) % words.length
    }

    setTimeout(type, isDeleting ? 60 : 100)
  }

  type()
})

const resumeBtns = document.querySelectorAll(".resume-btn")

resumeBtns.forEach((btn, idx) => {
  btn.addEventListener("click", () => {
    const resumeDetails = document.querySelectorAll(".resume-detail")

    resumeBtns.forEach((btn) => {
      btn.classList.remove("active")
    })
    btn.classList.add("active")

    resumeDetails.forEach((detail) => {
      detail.classList.remove("active")
    })
    resumeDetails[idx].classList.add("active")
  })
})

const arrowRight = document.querySelector(".portfolio-box .navigation .arrow-right")
const arrowLeft = document.querySelector(".portfolio-box .navigation .arrow-left")

let index = 0
let startX = 0
let isDragging = false

const activePortfolio = () => {
  const imgSlide = document.querySelector(".portfolio-carousel .img-slide")
  const portfolioDetails = document.querySelectorAll(".portfolio-detail")

  imgSlide.style.transform = `translateX(calc(${index * -100}% - ${index * 2}rem))`

  portfolioDetails.forEach((detail) => {
    detail.classList.remove("active")
  })
  portfolioDetails[index].classList.add("active")

  // Update navigation buttons
  arrowLeft.classList.toggle("disabled", index === 0)
  arrowRight.classList.toggle("disabled", index === 5)
}

// Arrow navigation
arrowRight.addEventListener("click", () => {
  if (index < 5) {
    index++
    activePortfolio()
  }
})

arrowLeft.addEventListener("click", () => {
  if (index > 0) {
    index--
    activePortfolio()
  }
})

// Touch/swipe functionality for portfolio carousel
const portfolioCarousel = document.querySelector(".portfolio-carousel")

if (portfolioCarousel) {
  // Touch events
  portfolioCarousel.addEventListener("touchstart", (e) => {
    startX = e.touches[0].clientX
    isDragging = true
  })

  portfolioCarousel.addEventListener("touchmove", (e) => {
    if (!isDragging) return
    e.preventDefault()
  })

  portfolioCarousel.addEventListener("touchend", (e) => {
    if (!isDragging) return

    const endX = e.changedTouches[0].clientX
    const diffX = startX - endX

    if (Math.abs(diffX) > 50) {
      // Minimum swipe distance
      if (diffX > 0 && index < 5) {
        // Swipe left - next
        index++
      } else if (diffX < 0 && index > 0) {
        // Swipe right - previous
        index--
      }
      activePortfolio()
    }

    isDragging = false
  })

  // Mouse events for desktop
  portfolioCarousel.addEventListener("mousedown", (e) => {
    startX = e.clientX
    isDragging = true
    portfolioCarousel.style.cursor = "grabbing"
  })

  portfolioCarousel.addEventListener("mousemove", (e) => {
    if (!isDragging) return
    e.preventDefault()
  })

  portfolioCarousel.addEventListener("mouseup", (e) => {
    if (!isDragging) return

    const endX = e.clientX
    const diffX = startX - endX

    if (Math.abs(diffX) > 50) {
      if (diffX > 0 && index < 5) {
        index++
      } else if (diffX < 0 && index > 0) {
        index--
      }
      activePortfolio()
    }

    isDragging = false
    portfolioCarousel.style.cursor = "grab"
  })

  portfolioCarousel.addEventListener("mouseleave", () => {
    isDragging = false
    portfolioCarousel.style.cursor = "grab"
  })
}

// Initialize portfolio
activePortfolio()

// Enhanced Contact Form Handling with Mobile Optimizations
const contactForm = document.getElementById("contactForm")
const submitBtn = document.getElementById("submitBtn")
const formStatus = document.getElementById("form-status")

if (contactForm) {
  // Add input focus effects for mobile
  const inputs = contactForm.querySelectorAll("input, textarea")
  inputs.forEach((input) => {
    input.addEventListener("focus", () => {
      input.parentElement.classList.add("focused")
    })

    input.addEventListener("blur", () => {
      if (!input.value) {
        input.parentElement.classList.remove("focused")
      }
    })
  })

  contactForm.addEventListener("submit", async (e) => {
    e.preventDefault()

    // Get form data
    const formData = {
      name: document.getElementById("name").value.trim(),
      age: document.getElementById("age").value,
      email: document.getElementById("email").value.trim(),
      subject: document.getElementById("subject").value.trim(),
      message: document.getElementById("query").value.trim(),
    }

    // Basic validation
    if (!formData.name || !formData.age || !formData.email || !formData.message) {
      showFormStatus("error", "Please fill in all required fields.")
      return
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(formData.email)) {
      showFormStatus("error", "Please enter a valid email address.")
      return
    }

    // Age validation
    if (formData.age < 1 || formData.age > 120) {
      showFormStatus("error", "Please enter a valid age between 1 and 120.")
      return
    }

    // Show loading state
    submitBtn.disabled = true
    submitBtn.innerHTML = '<span class="btn-text">Opening Email...</span><i class="bx bx-loader-alt bx-spin"></i>'

    // Hide previous status messages
    formStatus.style.display = "none"
    formStatus.className = "form-status"

    try {
      // Create email content
      const emailSubject = formData.subject ? `Portfolio Contact: ${formData.subject}` : "Portfolio Contact Form"

      const emailBody = `Hi Dhruv,

I'm reaching out through your portfolio website. Here are my details:

Name: ${formData.name}
Age: ${formData.age}
Email: ${formData.email}
${formData.subject ? `Subject: ${formData.subject}` : ""}

Message:
${formData.message}

Best regards,
${formData.name}`

      // Create mailto link
      const mailtoLink = `mailto:dhruvkhera2@gmail.com?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`

      // Open email client
      window.location.href = mailtoLink

      // Show success message
      showFormStatus("success", "Your email client should open now with a pre-filled message. Just click send!")

      // Reset form after a short delay
      setTimeout(() => {
        contactForm.reset()
        inputs.forEach((input) => {
          input.parentElement.classList.remove("focused")
        })
      }, 2000)
    } catch (error) {
      showFormStatus(
        "error",
        "Unable to open email client. Please copy this email: dhruvkhera2@gmail.com and send your message manually.",
      )
    } finally {
      // Re-enable submit button after a short delay
      setTimeout(() => {
        submitBtn.disabled = false
        submitBtn.innerHTML = '<span class="btn-text">Send Message</span><i class="bx bx-send"></i>'
      }, 2000)
    }
  })
}

function showFormStatus(type, message) {
  formStatus.className = `form-status ${type}`
  formStatus.textContent = message
  formStatus.style.display = "block"

  // Auto-hide messages after 8 seconds
  setTimeout(() => {
    formStatus.style.display = "none"
  }, 8000)

  // Scroll to status message on mobile
  if (window.innerWidth <= 768) {
    formStatus.scrollIntoView({ behavior: "smooth", block: "center" })
  }
}
